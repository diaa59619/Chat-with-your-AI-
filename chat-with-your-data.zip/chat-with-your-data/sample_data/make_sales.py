"""Generates a deliberately messy sales CSV (title rows, $ strings, mixed dates, totals row, spelling variants)."""
import random, csv
random.seed(1)
regions = ["North", "South", "East", "West"]; cities = ["Delhi", "delhi ", "Mumbai", "Pune"]
cats = {"Laptop": 900, "Phone": 500, "Desk": 250, "Chair": 120}
rows = [["ACME Corp Sales Export"], [], ["Order ID", "Order Date", "Customer", "Region", "City", "Category", "Qty", "Revenue", "Profit", "Discount"]]
for i in range(1, 301):
    c = random.choice(list(cats)); q = random.randint(1, 5); d = random.choice([0, 0.1, 0.25, 0.3])
    rev = cats[c] * q * (1 - d); prof = rev * random.uniform(-0.1, 0.3)
    rows.append([f"O{i:04d}", f"{random.randint(1,28):02d}/{random.randint(1,12):02d}/{random.choice([2022,2023])}",
                 f"Cust{random.randint(1,40)}", random.choice(regions), random.choice(cities), c, q,
                 f"${rev:,.2f}", f"{prof:.2f}", f"{int(d*100)}%"])
rows.append(["Total", "", "", "", "", "", "", "", "", ""])
csv.writer(open("sample_data/sales_messy.csv", "w", newline="")).writerows(rows)
