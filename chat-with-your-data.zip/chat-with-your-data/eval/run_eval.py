"""End-to-end eval against a REAL LLM. Ground truth computed independently with pandas.
Extend eval/questions.json to >=100 questions (see README). Fails (exit 1) if accuracy < 90%."""
import json, sys, pathlib, collections
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from backend.llm import LLM
from backend.pipeline.clean import load_file, clean_df
from backend.pipeline.profile import profile
from backend.pipeline.pipeline import answer

raw, _, _ = load_file("s.csv", open("sample_data/sales_messy.csv", "rb").read())
df, tags, _ = clean_df(raw["data"])
truth = {"sum": df["Revenue"].sum(), "count": df["Order ID"].nunique(), "avg": df["Revenue"].mean()}
stats = collections.defaultdict(lambda: [0, 0])
for item in json.load(open("eval/questions.json")):
    s = {"df": df, "sheets": {"data": df}, "profile": profile(df, tags), "history": []}
    out = answer(LLM(), s, item["q"]); ok = False
    try:
        ok = out["status"] == "ok" and abs(float(out["headline"].replace(",", "")) - truth[item["truth"]]) < 0.01 * max(1, abs(truth[item["truth"]])) / 100
    except Exception: pass
    for k in (item["intent"], item["style"]): stats[k][0] += ok; stats[k][1] += 1
tot = [sum(v[0] for v in stats.values()), sum(v[1] for v in stats.values())]
for k, (a, n) in stats.items(): print(f"{k:12s} {a}/{n}")
acc = sum(v[0] for k, v in stats.items() if k in {"sum","count","avg"}) / max(1, len(json.load(open('eval/questions.json'))))
print(f"overall accuracy: {acc:.0%}"); sys.exit(0 if acc >= 0.9 else 1)
