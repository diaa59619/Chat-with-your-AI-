"""FastAPI app. Sessions are in-memory with TTL; uploads are never written to disk."""
from __future__ import annotations
import csv, io, os, time, uuid
from fastapi import FastAPI, File, HTTPException, UploadFile, Request
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from .llm import LLM, LLMError
from .pipeline.clean import load_file, clean_df
from .pipeline.profile import profile
from .pipeline.pipeline import answer

app = FastAPI(title="Chat with Your Data")
SESSIONS: dict[str, dict] = {}
TTL = int(os.getenv("SESSION_TTL_S", 3600))
MAX = int(os.getenv("MAX_UPLOAD_MB", 50)) * 1024 * 1024
_hits: dict[str, list[float]] = {}
llm = LLM()


def _limit(req: Request, n: int = 30) -> None:
    ip, now = req.client.host if req.client else "?", time.time()
    _hits[ip] = [t for t in _hits.get(ip, []) if now - t < 60] + [now]
    if len(_hits[ip]) > n:
        raise HTTPException(429, "Too many requests. Please slow down.")


def _gc() -> None:
    for k in [k for k, v in SESSIONS.items() if time.time() - v["t"] > TTL]:
        del SESSIONS[k]


def _safe_cell(v):
    return "'" + v if isinstance(v, str) and v[:1] in "=+-@" else v


@app.post("/api/upload")
async def upload(req: Request, file: UploadFile = File(...)):
    _limit(req, 10); _gc()
    data = await file.read(MAX + 1)
    if len(data) > MAX:
        raise HTTPException(413, "File is too large.")
    try:
        raw, maps, log = load_file(file.filename or "", data)
    except Exception as e:
        raise HTTPException(400, str(e))
    sheets, tags, profs = {}, {}, {}
    for n, r in raw.items():
        sheets[n], tags[n], l = clean_df(r)
        log += [f"[{n}] {x}" for x in l]
        profs[n] = profile(sheets[n], tags[n], maps[n])
    first = next(iter(sheets))
    sid = uuid.uuid4().hex
    SESSIONS[sid] = {"t": time.time(), "sheets": sheets, "df": sheets[first], "profile": profs[first],
                     "profiles": profs, "history": [], "active": first}
    return {"session": sid, "sheets": list(sheets), "active": first, "profile": profs[first], "log": log,
            "preview": sheets[first].head(20).astype(str).to_dict("records")}


class Q(BaseModel):
    session: str
    question: str
    sheet: str | None = None


@app.post("/api/ask")
def ask(q: Q, req: Request):
    _limit(req)
    s = SESSIONS.get(q.session)
    if not s:
        raise HTTPException(404, "Session expired. Please upload your file again.")
    s["t"] = time.time()
    if q.sheet and q.sheet in s["sheets"]:
        s["df"], s["profile"] = s["sheets"][q.sheet], s["profiles"][q.sheet]
    try:
        out = answer(llm, s, q.question[:2000])
    except LLMError as e:
        raise HTTPException(503, str(e))
    if out.get("result", {}).get("full_csv") is not None:
        s["last_csv"] = out["result"].pop("full_csv")
    elif "result" in out:
        out["result"].pop("full_csv", None)
    return out


@app.get("/api/download/{sid}")
def download(sid: str):
    s = SESSIONS.get(sid)
    if not s or "last_csv" not in s:
        raise HTTPException(404, "Nothing to download.")
    rows = [[_safe_cell(c) for c in r] for r in csv.reader(io.StringIO(s["last_csv"]))]
    buf = io.StringIO(); csv.writer(buf).writerows(rows)
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=result.csv"})


@app.post("/api/feedback")
def feedback(body: dict):
    return {"ok": True}  # feedback stores only rating + question in a real deployment (opt-in)


if os.path.isdir("frontend"):
    app.mount("/", StaticFiles(directory="frontend", html=True), name="ui")
