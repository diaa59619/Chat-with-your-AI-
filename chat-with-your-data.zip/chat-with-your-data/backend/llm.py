"""Single adapter around the LLM provider. Swap by editing/implementing `LLM.complete`."""
from __future__ import annotations
import json, os, time, urllib.request


class LLMError(Exception):
    pass


class LLM:
    def __init__(self) -> None:
        self.provider = os.getenv("LLM_PROVIDER", "anthropic")
        self.key = os.getenv("LLM_API_KEY", "")
        self.model = os.getenv("LLM_MODEL", "claude-sonnet-4-6")
        self.base = os.getenv("LLM_BASE_URL", "")

    def complete(self, system: str, user: str, temperature: float = 0.0, retries: int = 3) -> str:
        if not self.key:
            raise LLMError("LLM_API_KEY is not set.")
        for i in range(retries):
            try:
                return self._call(system, user, temperature)
            except Exception as e:  # timeouts, 429, 5xx
                if i == retries - 1:
                    raise LLMError("The AI service is unavailable right now. Please try again shortly.") from e
                time.sleep(2 ** i)
        raise LLMError("unreachable")

    def _call(self, system: str, user: str, temperature: float) -> str:
        if self.provider == "anthropic":
            url = (self.base or "https://api.anthropic.com") + "/v1/messages"
            body = {"model": self.model, "max_tokens": 3000, "temperature": temperature, "system": system,
                    "messages": [{"role": "user", "content": user}]}
            hdr = {"x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
            r = json.load(urllib.request.urlopen(urllib.request.Request(url, json.dumps(body).encode(), hdr), timeout=60))
            return "".join(b.get("text", "") for b in r["content"])
        url = (self.base or "https://api.openai.com/v1") + "/chat/completions"
        body = {"model": self.model, "temperature": temperature,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
        hdr = {"Authorization": f"Bearer {self.key}", "content-type": "application/json"}
        r = json.load(urllib.request.urlopen(urllib.request.Request(url, json.dumps(body).encode(), hdr), timeout=60))
        return r["choices"][0]["message"]["content"]
