"""Stage 4b: execute generated code in a resource-limited subprocess (run the whole API in Docker with
network disabled for the full isolation story; see README)."""
from __future__ import annotations
import json, os, pickle, resource, subprocess, sys, tempfile
import pandas as pd

RUNNER = r'''
import sys, json, pickle, builtins, math
import pandas as pd, numpy as np
try:
    import plotly.express as px, plotly.graph_objects as go
except Exception:
    px = go = None
p = pickle.load(open(sys.argv[1], "rb"))
names = ["len","range","min","max","sum","abs","round","sorted","list","dict","set","tuple","str","int","float",
         "bool","enumerate","zip","any","all","isinstance","map","filter","reversed","print","divmod","pow"]
safe = {k: getattr(builtins, k) for k in names}
env = {"df": p["df"], "sheets": p["sheets"], "pd": pd, "np": np, "px": px, "go": go, "math": math}
exec(compile(p["code"], "<generated>", "exec"), {"__builtins__": safe}, env)
r = env.get("result"); out = {}
if isinstance(r, pd.Series):
    r = r.reset_index() if r.name is not None or r.index.name else r.to_frame("value").reset_index()
if isinstance(r, pd.DataFrame):
    out = {"kind": "table", "rows_total": len(r), "data": json.loads(r.head(100).to_json(orient="split", date_format="iso"))}
    out["full_csv"] = r.to_csv(index=False) if len(r) <= 100000 else None
elif r is None:
    out = {"kind": "none"}
else:
    try: v = r.item() if hasattr(r, "item") else r
    except Exception: v = r
    out = {"kind": "scalar", "value": v if isinstance(v, (int, float, str, bool)) else str(v)}
fig = env.get("fig")
out["fig"] = json.loads(fig.to_json()) if fig is not None and hasattr(fig, "to_json") else None
print("@@RESULT@@" + json.dumps(out, default=str))
'''


class SandboxError(Exception):
    pass


def run_code(code: str, df: pd.DataFrame, sheets: dict | None = None, timeout: int | None = None,
             mem_mb: int | None = None) -> dict:
    timeout = timeout or int(os.getenv("EXEC_TIMEOUT_S", 20))
    mem = (mem_mb or int(os.getenv("EXEC_MEM_MB", 1024))) * 1024 * 1024

    def limits():
        resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
        resource.setrlimit(resource.RLIMIT_CPU, (timeout, timeout))
        resource.setrlimit(resource.RLIMIT_FSIZE, (50 * 1024 * 1024,) * 2)
        resource.setrlimit(resource.RLIMIT_NPROC, (64, 64)) if False else None
        os.setsid()

    with tempfile.TemporaryDirectory() as d:
        pk = os.path.join(d, "in.pkl")
        with open(pk, "wb") as f:
            pickle.dump({"df": df, "sheets": sheets or {}, "code": code}, f)
        rn = os.path.join(d, "runner.py")
        open(rn, "w").write(RUNNER)
        try:
            proc = subprocess.run([sys.executable, "-I", rn, pk], capture_output=True, text=True, timeout=timeout,
                                  cwd=d, env={"PATH": os.environ.get("PATH", ""), "HOME": d},
                                  preexec_fn=limits)
        except subprocess.TimeoutExpired:
            raise SandboxError(f"Execution timed out after {timeout}s.")
    if proc.returncode != 0:
        tail = "\n".join(proc.stderr.strip().splitlines()[-6:])
        raise SandboxError(tail or f"Process exited with code {proc.returncode}")
    for line in proc.stdout.splitlines():
        if line.startswith("@@RESULT@@"):
            return json.loads(line[len("@@RESULT@@"):])
    raise SandboxError("No result produced.")
