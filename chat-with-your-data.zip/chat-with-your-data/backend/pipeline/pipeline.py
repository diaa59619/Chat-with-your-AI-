"""Orchestrates stages 2-7. Every number shown comes from sandbox-executed code."""
from __future__ import annotations
import json, re
from pathlib import Path
import pandas as pd
from .understand import normalize, resolve_columns, resolve_values, prefilter
from .validate import validate_code, ValidationError
from .sandbox import run_code, SandboxError
from .verify import sanity, agree

PROMPTS = Path(__file__).parent.parent / "prompts"
MAX_TRIES = 3


def _p(name: str) -> str:
    return (PROMPTS / name).read_text()


def _json(txt: str) -> dict:
    txt = re.sub(r"^```(?:json)?|```$", "", txt.strip(), flags=re.M).strip()
    return json.loads(txt[txt.find("{"): txt.rfind("}") + 1])


def _generate(llm, system, payload, history_note="") -> dict:
    return _json(llm.complete(system, payload + history_note))


def _attempt(llm, system, payload, df, sheets, q) -> tuple[dict | None, dict | None, str]:
    """Generate -> validate -> run -> sanity, with up to MAX_TRIES self-repairs."""
    note, spec, last = "", None, ""
    for _ in range(MAX_TRIES):
        try:
            spec = _generate(llm, system, payload, note)
        except Exception as e:
            note, last = f"\nYour last reply was not valid JSON ({e}). Return strict JSON only.", str(e)
            continue
        if spec.get("needs_clarification"):
            return spec, None, ""
        try:
            validate_code(spec["code"])
            res = run_code(spec["code"], df, sheets)
            probs = [x for x in sanity(res, q, len(df)) if x != "EMPTY"]
            if probs:
                raise SandboxError("; ".join(probs))
            return spec, res, ""
        except (ValidationError, SandboxError, KeyError) as e:
            last = str(e)
            note = f"\nYour previous code failed: {last}\nPrevious code:\n{spec.get('code')}\nFix it."
    return spec, None, last


def answer(llm, session: dict, question: str) -> dict:
    """session: {df, sheets, profile, history, filters}"""
    pre = prefilter(question)
    if pre:
        return {"status": "info", "message": pre}
    q = normalize(question)
    prof, df = session["profile"], session["df"]
    cols = resolve_columns(q, prof)
    if cols["ambiguous"]:
        ph, opts = next(iter(cols["ambiguous"].items()))
        return {"status": "clarify", "message": f"'{ph}' could mean more than one column. Which did you mean?",
                "options": opts}
    payload = json.dumps({"schema": prof, "question": q, "column_matches": cols["matches"],
                          "value_matches": resolve_values(q, prof), "context": session["history"][-6:],
                          "dataset_variable": "df"}, default=str)
    spec, res, err = _attempt(llm, _p("codegen_system.txt"), payload, df, session.get("sheets"), q)
    if spec and spec.get("needs_clarification"):
        return {"status": "clarify", "message": spec.get("clarifying_question") or "Could you rephrase that?",
                "options": spec.get("clarifying_options", [])}
    if res is None:
        return {"status": "uncertain", "message": "I couldn't produce a verified answer. "
                f"Last problem: {err}. Could you say which column or filter you mean?"}
    # Self-consistency: independent second solution for scalars/small tables
    confidence = "Medium"
    if res["kind"] in ("scalar", "table") and res.get("rows_total", 1) <= 100:
        spec2, res2, _ = _attempt(llm, _p("alt_system.txt") + "\n" + _p("codegen_system.txt"), payload, df,
                                  session.get("sheets"), q)
        if res2 is not None:
            if agree(res, res2):
                confidence = "High"
            else:
                return {"status": "uncertain", "confidence": "Low",
                        "message": "Two independent calculations disagreed, so I won't state a number. "
                                   f"My reading was: {spec.get('interpretation')}. Can you confirm or rephrase?"}
    if res["kind"] == "table" and res["rows_total"] == 0:
        return {"status": "ok", "headline": "No rows matched", "explanation":
                f"No rows matched. Interpretation: {spec.get('interpretation')}. Check spellings of filter values.",
                "code": spec["code"], "result": res, "confidence": confidence, "chart": None, "rows": f"0 of {len(df)}"}
    expl = explain(llm, spec, res)
    session["history"].append({"q": q, "interpretation": spec.get("interpretation"),
                               "assumptions": spec.get("assumptions", [])})
    return {"status": "ok", "headline": headline(res), "explanation": expl, "assumptions": spec.get("assumptions", []),
            "code": spec["code"], "result": res, "chart": res.get("fig"), "chart_spec": spec.get("chart"),
            "confidence": confidence, "rows": f"Based on {len(df)} rows",
            "followups": ["Break this down by another column", "Show the trend over time", "What are the top 5?"]}


def headline(res: dict) -> str:
    if res["kind"] == "scalar":
        v = res["value"]
        return f"{v:,.2f}".rstrip("0").rstrip(".") if isinstance(v, float) else f"{v:,}" if isinstance(v, int) else str(v)
    return f"{res.get('rows_total', 0)} row(s)"


def explain(llm, spec: dict, res: dict) -> str:
    try:
        body = json.dumps({"interpretation": spec.get("interpretation"), "assumptions": spec.get("assumptions"),
                           "result": res.get("value") if res["kind"] == "scalar" else res["data"]}, default=str)
        return llm.complete(_p("explain_system.txt"), body).strip()
    except Exception:
        return spec.get("interpretation", "")  # never blocks the verified number
