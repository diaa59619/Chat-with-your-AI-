"""Stage 1b: compact schema card for the LLM (never the raw data)."""
from __future__ import annotations
import pandas as pd


def profile(df: pd.DataFrame, tags: dict[str, str], name_map: dict[str, str] | None = None) -> dict:
    cols = []
    for c in df.columns:
        s = df[c]
        info = {"name": c, "original_name": (name_map or {}).get(c, c), "dtype": str(s.dtype),
                "semantic_type": tags.get(c, "text"), "pct_missing": round(float(s.isna().mean() * 100), 2),
                "n_unique": int(s.nunique())}
        if pd.api.types.is_numeric_dtype(s) and s.dtype != bool:
            info.update(min=float(s.min()), max=float(s.max()), mean=float(s.mean()))
        elif pd.api.types.is_datetime64_any_dtype(s):
            info.update(min=str(s.min()), max=str(s.max()))
        elif tags.get(c) == "categorical":
            vc = s.value_counts()
            info["values"] = list(vc.index) if len(vc) <= 50 else list(vc.index[:30])
            if len(vc) > 50:
                info["other_count"] = int(len(vc) - 30)
        cols.append(info)
    dates = [c["name"] for c in cols if c["semantic_type"] == "date"]
    return {"rows": len(df), "columns": cols, "default_time_axis": dates[0] if dates else None,
            "measures": [c["name"] for c in cols if c["semantic_type"] in ("numeric", "currency", "percentage")],
            "dimensions": [c["name"] for c in cols if c["semantic_type"] in ("categorical", "boolean")],
            "sample_rows": df.head(5).astype(str).to_dict("records")}
