"""Stage 2: normalization + column/value grounding (exact -> fuzzy -> synonym via LLM at codegen time)."""
from __future__ import annotations
import re
from rapidfuzz import fuzz, process

ABBR = {"rev": "revenue", "qty": "quantity", "avg": "average", "yoy": "year over year", "mom": "month over month",
        "qoq": "quarter over quarter", "cust": "customers", "prod": "product", "amt": "amount", "pct": "percent",
        "sku": "sku", "mgr": "manager", "emp": "employee"}
SMALL_TALK = re.compile(r"^(hi|hello|hey|thanks|thank you|who are you|how are you)\W*$", re.I)
MUTATE = re.compile(r"\b(delete|drop|remove|update|modify|overwrite|edit)\b.*\b(row|rows|column|data|record|cell)", re.I)


def normalize(q: str) -> str:
    words = re.findall(r"\w+|\S", q.strip())
    return " ".join(ABBR.get(w.lower(), w) for w in words).replace(" ,", ",").replace(" ?", "?")


def resolve_columns(question: str, prof: dict, threshold: int = 80) -> dict:
    """Return {phrase: [(column, score)]} for n-grams that fuzzy-match column names; flag ambiguity."""
    cols = [c["name"] for c in prof["columns"]]
    toks = re.findall(r"\w+", question.lower())
    grams = {" ".join(toks[i:i + n]) for n in (1, 2, 3) for i in range(len(toks) - n + 1)}
    out, ambiguous = {}, {}
    norm = {c: re.sub(r"[_\W]+", " ", c.lower()).strip() for c in cols}
    for g in grams:
        if len(g) < 3:
            continue
        hits = [(c, fuzz.WRatio(g, norm[c])) for c in cols]
        hits = sorted([h for h in hits if h[1] >= threshold], key=lambda x: -x[1])[:3]
        if hits:
            out[g] = hits
            if len(hits) > 1 and hits[0][1] - hits[1][1] < 5 and hits[0][1] < 100 and \
                    not any(norm[h[0]] == g for h in hits):
                ambiguous[g] = [h[0] for h in hits]
    return {"matches": out, "ambiguous": ambiguous}


def resolve_values(question: str, prof: dict) -> dict:
    """Map words in the question to actual categorical cell values (fuzzy)."""
    found = {}
    toks = [t for t in re.findall(r"\w+", question) if len(t) > 2]
    for c in prof["columns"]:
        vals = [str(v) for v in c.get("values", [])]
        if not vals:
            continue
        for t in toks:
            m = process.extractOne(t, vals, scorer=fuzz.WRatio, score_cutoff=88)
            if m:
                found.setdefault(c["name"], []).append({"mentioned": t, "matches": m[0]})
    return found


def prefilter(question: str):
    if SMALL_TALK.match(question.strip()):
        return "I'm here to answer questions about your spreadsheet. Try asking for totals, top items or trends."
    if MUTATE.search(question):
        return "This app is read-only on your data, so I can't modify or delete anything. I can analyse it though."
    return None
