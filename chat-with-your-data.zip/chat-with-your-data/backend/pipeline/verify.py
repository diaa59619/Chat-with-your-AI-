"""Stage 5: sanity checks and self-consistency."""
from __future__ import annotations
import math, re


def sanity(res: dict, question: str, n_rows: int) -> list[str]:
    """Return a list of problems (empty = OK)."""
    p = []
    if res["kind"] == "none":
        return ["Result is None."]
    if res["kind"] == "scalar":
        v = res["value"]
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            p.append("Result is NaN/inf.")
        if re.search(r"\b(percent|percentage|%|share)\b", question, re.I) and isinstance(v, (int, float)) \
                and not 0 <= v <= 100.0001 and not re.search(r"growth|change|vs|compare", question, re.I):
            p.append(f"Percentage {v} is outside 0-100.")
        if re.search(r"\b(how many|count|number of)\b", question, re.I) and isinstance(v, (int, float)):
            if v < 0 or v != int(v) or v > n_rows * 1000:
                p.append(f"Count {v} is not a plausible non-negative integer.")
    if res["kind"] == "table" and res["rows_total"] == 0:
        p.append("EMPTY")  # caller decides whether this is a legitimate 'no match'
    return p


def agree(a: dict, b: dict, tol: float = 1e-6) -> bool:
    """Compare two independently produced results."""
    if a["kind"] != b["kind"]:
        return False
    if a["kind"] == "scalar":
        x, y = a["value"], b["value"]
        if isinstance(x, (int, float)) and isinstance(y, (int, float)):
            return math.isclose(x, y, rel_tol=1e-6, abs_tol=tol)
        return str(x).strip().lower() == str(y).strip().lower()
    if a["kind"] == "table":
        if a["rows_total"] != b["rows_total"]:
            return False
        fa = [v for r in a["data"]["data"] for v in r if isinstance(v, (int, float))]
        fb = [v for r in b["data"]["data"] for v in r if isinstance(v, (int, float))]
        return len(fa) == len(fb) and all(math.isclose(x, y, rel_tol=1e-6, abs_tol=tol) for x, y in zip(sorted(fa), sorted(fb)))
    return True
