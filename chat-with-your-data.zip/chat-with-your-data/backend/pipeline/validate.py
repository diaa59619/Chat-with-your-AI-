"""Stage 4a: AST allow-list validation of generated code."""
from __future__ import annotations
import ast

BANNED_NAMES = {"open", "eval", "exec", "compile", "__import__", "getattr", "setattr", "delattr", "globals",
                "locals", "vars", "input", "os", "sys", "subprocess", "socket", "builtins", "breakpoint",
                "importlib", "shutil", "pathlib", "requests"}
BANNED_ATTRS = {"read_csv", "read_excel", "read_pickle", "read_parquet", "read_json", "read_html", "read_sql",
                "to_pickle", "to_csv", "to_excel", "to_parquet", "to_json_file", "eval", "query_file", "system",
                "popen", "write_html", "write_image", "write_json", "to_clipboard"}


class ValidationError(Exception):
    pass


def validate_code(code: str) -> None:
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        raise ValidationError(f"Syntax error: {e}")
    for n in ast.walk(tree):
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            raise ValidationError("Imports are not allowed; pd, np and px are preloaded.")
        if isinstance(n, ast.Name) and (n.id in BANNED_NAMES or (n.id.startswith("__"))):
            raise ValidationError(f"Use of '{n.id}' is not allowed.")
        if isinstance(n, ast.Attribute) and (n.attr.startswith("_") or n.attr in BANNED_ATTRS):
            raise ValidationError(f"Access to attribute '{n.attr}' is not allowed.")
        if isinstance(n, ast.While):
            raise ValidationError("'while' loops are not allowed.")
        if isinstance(n, (ast.Global, ast.Nonlocal, ast.AsyncFunctionDef, ast.Await)):
            raise ValidationError("Disallowed statement.")
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and "__" in n.value:
            raise ValidationError("Dunder strings are not allowed.")
    if not any(isinstance(n, ast.Name) and n.id == "result" and isinstance(n.ctx, ast.Store) for n in ast.walk(tree)):
        raise ValidationError("Code must assign a variable named `result`.")
