"""Stage 1: ingest + non-destructive cleaning. Original frames are never mutated."""
from __future__ import annotations
import io, re, warnings
import chardet
import pandas as pd

NA_TOKENS = {"n/a", "na", "null", "-", "--", "none", "", "nan"}
_NUM = re.compile(r"[-+]?[\d,]*\.?\d+")
_MULT = {"k": 1e3, "m": 1e6, "b": 1e9}


def _sniff_delim(text: str) -> str:
    head = text[:5000]
    return max([",", ";", "\t", "|"], key=head.count)


def _find_header(raw: pd.DataFrame) -> int:
    """First row (within top 15) that is mostly filled, string-like, and unique."""
    width = raw.notna().sum(axis=1).max()
    for i in range(min(15, len(raw))):
        row = raw.iloc[i]
        vals = row.dropna().astype(str)
        if len(vals) >= 0.6 * width and sum(_to_num(v) == _to_num(v) for v in vals) <= 0.3 * len(vals):
            return i
    return 0


def _finish(raw: pd.DataFrame, log: list[str]) -> tuple[pd.DataFrame, dict[str, str]]:
    raw = raw.dropna(how="all").dropna(axis=1, how="all").reset_index(drop=True)
    if raw.empty:
        raise ValueError("The file has no data.")
    h = _find_header(raw)
    if h:
        log.append(f"Skipped {h} title/blank row(s) above the header.")
    names = [str(x).strip() if pd.notna(x) else "" for x in raw.iloc[h]]
    seen: dict[str, int] = {}
    cols, mapping = [], {}
    for i, n in enumerate(names):
        new = n or f"col_{i+1}"
        if new in seen:
            seen[new] += 1
            new = f"{new}_{seen[new]}"
        else:
            seen[new] = 1
        cols.append(new)
        mapping[new] = n or f"(blank #{i+1})"
        if new != n:
            log.append(f"Renamed column '{n or '(blank)'}' to '{new}'.")
    df = raw.iloc[h + 1:].copy()
    df.columns = cols
    df = df.reset_index(drop=True)
    if len(df) and re.search(r"\btotal\b", str(df.iloc[-1, 0]), re.I):
        log.append(f"Flagged and excluded trailing summary row: {df.iloc[-1, 0]!r}.")
        df = df.iloc[:-1]
    return df, mapping


def load_file(name: str, data: bytes) -> tuple[dict[str, pd.DataFrame], dict[str, dict], list[str]]:
    """Return ({sheet: raw df (strings)}, {sheet: name mapping}, log)."""
    log: list[str] = []
    low = name.lower()
    out, maps = {}, {}
    if not data:
        raise ValueError("The file is empty.")
    if low.endswith((".csv", ".tsv", ".txt")):
        enc = chardet.detect(data[:100000])["encoding"] or "utf-8"
        text = data.decode(enc, errors="replace")
        delim = "\t" if low.endswith(".tsv") else _sniff_delim(text)
        import csv
        rows = list(csv.reader(io.StringIO(text), delimiter=delim))
        w = max((len(r) for r in rows), default=0)
        raw = pd.DataFrame([r + [None] * (w - len(r)) for r in rows], dtype=object)
        raw = raw.replace({"": None})
        log.append(f"Detected encoding {enc} and delimiter {delim!r}.")
        out["data"], maps["data"] = _finish(raw, log)
    elif low.endswith((".xlsx", ".xls")):
        if not (data[:2] == b"PK" or data[:4] == b"\xd0\xcf\x11\xe0"):
            raise ValueError("File content does not look like an Excel workbook.")
        sheets = pd.read_excel(io.BytesIO(data), sheet_name=None, header=None, dtype=str)
        for sn, raw in sheets.items():
            try:
                out[sn], maps[sn] = _finish(raw, log)
            except ValueError:
                log.append(f"Sheet '{sn}' is empty and was ignored.")
        if not out:
            raise ValueError("The workbook has no data.")
    else:
        raise ValueError("Unsupported file type. Use CSV, TSV, XLSX or XLS.")
    return out, maps, log


def _to_num(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    t = re.sub(r"[$€£₹%\s]", "", str(v).strip())
    neg = t.startswith("(") and t.endswith(")")
    t = t.strip("()")
    mult = 1.0
    if t and t[-1].lower() in _MULT and len(t) > 1:
        mult, t = _MULT[t[-1].lower()], t[:-1]
    if not _NUM.fullmatch(t):
        return float("nan")
    x = float(t.replace(",", "")) * mult
    return -x if neg else x


def _dayfirst(s: pd.Series) -> bool:
    for v in s.dropna().astype(str).head(500):
        m = re.match(r"^(\d{1,2})[/-](\d{1,2})[/-]\d{2,4}$", v.strip())
        if m and int(m.group(1)) > 12:
            return True
    return False


def clean_df(df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, str], list[str]]:
    """Return (cleaned copy, semantic tags per column, change log)."""
    df, log, tags = df.copy(), [], {}
    for c in df.columns:
        s = df[c].astype("string").str.strip()
        s = s.mask(s.str.lower().isin(NA_TOKENS))
        nn = s.dropna()
        if nn.empty:
            df[c], tags[c] = s, "empty"
            continue
        low = set(nn.str.lower().unique())
        if low <= {"yes", "no", "y", "n", "true", "false"}:
            df[c] = s.str.lower().isin({"yes", "y", "true"}).where(s.notna())
            tags[c] = "boolean"
            log.append(f"'{c}': converted Yes/No values to booleans.")
            continue
        nums = nn.map(_to_num)
        if nums.notna().mean() >= 0.9:
            ok = s.map(_to_num).astype(float)
            sample = " ".join(nn.head(200))
            tags[c] = "currency" if re.search(r"[$€£₹]", sample) else "percentage" if "%" in sample else "numeric"
            if re.search(r"(^|_|\b)(id|code|sku|no)($|_|\b)", c.lower()) and nn.nunique() > 0.9 * len(nn):
                tags[c] = "id"
            df[c] = ok
            if (nn.str.contains(r"[,$€£₹%()KkMmBb]", regex=True)).any():
                log.append(f"'{c}': converted text numbers (symbols/commas/K/M/parentheses) to numeric.")
            continue
        if nn.str.len().median() <= 30:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                try:
                    d = pd.to_datetime(s, dayfirst=_dayfirst(s), format="mixed", errors="coerce")
                except Exception:
                    d = pd.Series(pd.NaT, index=s.index)
            if d.notna().sum() >= 0.9 * len(nn) and not nn.str.fullmatch(r"\d+").all():
                df[c], tags[c] = d, "date"
                log.append(f"'{c}': parsed as dates ({'day' if _dayfirst(s) else 'month'}-first).")
                continue
        df[c] = s.astype(object)
        u = nn.nunique()
        tags[c] = "categorical" if u <= max(50, 0.2 * len(nn)) else "text"
        if re.search(r"(^|[_\s])(id|code|sku)($|[_\s])", c.lower()) and u > 0.9 * len(nn):
            tags[c] = "id"
        if (nn != nn.str.strip()).any():
            log.append(f"'{c}': trimmed whitespace.")
    return df, tags, log
