# Chat with Your Data

Upload a CSV/XLSX, ask questions in plain English, get a verified answer, explanation, chart, and the exact code run.

## Quick start
```bash
cp .env.example .env          # set LLM_API_KEY
docker-compose up --build     # http://localhost:8000
# or locally: pip install -r requirements.txt && uvicorn backend.api:app
python -m pytest tests        # unit + adversarial tests (no API key needed)
python eval/run_eval.py       # real-LLM accuracy eval (needs LLM_API_KEY)
```

## Architecture
```mermaid
flowchart LR
 U[Upload] --> C[clean.py] --> P[profile.py: schema card]
 Q[Question] --> N[understand.py: normalize + column/value grounding] --> G[LLM codegen -> strict JSON]
 P --> G --> V[validate.py: AST allow-list] --> S[sandbox.py: limited subprocess] --> R[verify.py: sanity + 2nd independent solution]
 R -->|agree| E[explain: LLM sees result table only] --> UI
 R -->|disagree / fail x3| H[honest clarifying question]
```

## How accuracy is ensured
Numbers only come from code executed on the real data. Generated code is validated, run, sanity-checked
(NaN, percent range, count integrality), then solved a second independent way; disagreement yields a
clarifying question, never a guess. Ambiguous column matches trigger a clarification before any code is written.
The explanation LLM only sees the executed result.

## Security model
Layered: (1) AST allow-list (no imports, dunders, file/IO attributes, `while`); (2) runner with a minimal builtins
set and no `__import__`/`open`; (3) subprocess with RLIMIT memory/CPU/file-size, timeout, isolated env;
(4) Docker: read-only FS, tmpfs, all caps dropped, non-root, pid/mem limits. Cell text is passed as JSON data and
the model's output is never executed unless it passes validation. CSV export neutralises `= + - @`. Uploads live
only in memory with a TTL (`SESSION_TTL_S`). Rate limiting is per-IP in memory.

## Prompts
See `backend/prompts/` (`codegen_system.txt`, `alt_system.txt`, `explain_system.txt`).

## Known limitations (honest status)
- **Network isolation** of the sandbox subprocess is not enforced by the code itself; add `network_mode: none` or
  put the app behind an egress-restricted network. The compose file does not set it because the app must call the LLM API.
  Stronger fix: run the sandbox as a separate no-network container (not implemented).
- **Not yet implemented:** cross-sheet joins (sheets are available as `sheets` but not auto-joined), user-resolved
  date-format question, category-spelling normalization UI, removable assumption chips, chart-type switcher/PNG
  download, streaming, voice, column retrieval for >200 columns, DuckDB for >1M rows, deterministic (non-LLM)
  fallback checks, only 1 of 3 sample datasets (sales), feedback persistence, XLSX result download.
- **Evaluation:** `eval/questions.json` has 3 seed questions, not 100. The 90% gate is wired but unproven; the real
  accuracy number must be measured with your LLM key.
- Date-ambiguity heuristic: day-first only if some value has day > 12; otherwise month-first.
- Excel merged-cell banners are handled only via the generic header-row detection.
